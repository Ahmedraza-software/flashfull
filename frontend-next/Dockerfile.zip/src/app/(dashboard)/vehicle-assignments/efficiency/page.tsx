"use client";

export { default } from "@/app/(dashboard)/assignment-efficiency/page";
