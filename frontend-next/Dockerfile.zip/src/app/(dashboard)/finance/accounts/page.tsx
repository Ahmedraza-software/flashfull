import { redirect } from "next/navigation";

export default function FinanceAccountsPage() {
  redirect("/accounts-advances");
}


